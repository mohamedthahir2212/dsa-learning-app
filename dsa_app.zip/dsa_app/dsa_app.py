"""
DSA Learning App
================

This script provides an interactive command‑line tool for learning
data structures and algorithms (DSA) using the OpenAI API.  Users can
select a topic and a difficulty level; the program will then query
OpenAI's ChatCompletion endpoint (e.g. GPT‑4o) to generate a lesson,
including explanations, code examples, and optionally a quiz.

Before running this script, make sure you have:
  * Installed the `openai` package (`pip install openai`)
  * Set your OpenAI API key in the environment variable `OPENAI_API_KEY`

Example usage:

    python dsa_app.py

You will be prompted to choose a topic and difficulty, and then the
application will fetch a custom lesson from the model.
"""

import os
import sys
from typing import Dict

try:
    import openai  # type: ignore
except ImportError:
    print("Error: The 'openai' library is not installed. Please run 'pip install openai' and try again.")
    sys.exit(1)


# System prompt defining the role of the assistant.  Adjust this
# string to modify the style or depth of the generated lessons.
SYSTEM_PROMPT = (
    "You are a patient and knowledgeable tutor who teaches Data Structures and Algorithms (DSA) "
    "to learners at various skill levels.  You provide clear explanations, illustrative examples, "
    "and Python code snippets where appropriate.  When asked to generate a quiz, you create short, "
    "multi‑choice or open‑ended questions with answers that reinforce the material just taught."
)

TOPICS: Dict[str, str] = {
    "1": "Arrays",
    "2": "Linked Lists",
    "3": "Stacks",
    "4": "Queues",
    "5": "Trees",
    "6": "Graphs",
    "7": "Sorting Algorithms",
    "8": "Searching Algorithms",
    "9": "Hash Tables",
    "10": "Dynamic Programming",
    "11": "Recursion",
    "12": "Algorithm Analysis (Big‑O)"
}

DIFFICULTIES: Dict[str, str] = {
    "1": "Beginner",
    "2": "Intermediate",
    "3": "Pro"
}


def ensure_api_key() -> str:
    """Retrieve the OpenAI API key from the environment or exit if not found."""
    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key:
        print(
            "Error: OPENAI_API_KEY environment variable not set.\n"
            "Please set your OpenAI API key before running this script."
        )
        sys.exit(1)
    return api_key


def generate_completion(messages: list) -> str:
    """
    Call the OpenAI ChatCompletion API with the provided messages and return
    the assistant's reply.  If the API call fails, an error message
    is returned instead.
    """
    try:
        response = openai.ChatCompletion.create(
            model="gpt-4o",
            messages=messages,
            temperature=0.7,
        )
        return response.choices[0].message["content"]
    except Exception as exc:
        return f"Error contacting OpenAI API: {exc}"


def generate_lesson(topic: str, difficulty: str) -> str:
    """
    Generate a lesson on the given topic and difficulty level using the
    ChatCompletion API.
    """
    messages = [
        {"role": "system", "content": SYSTEM_PROMPT},
        {
            "role": "user",
            "content": (
                f"Teach me about {topic} at a {difficulty} level. "
                "Explain the key concepts and provide Python code examples where relevant. "
                "Break the explanation into sections if needed, and encourage the learner with clear, approachable language."
            ),
        },
    ]
    return generate_completion(messages)


def generate_quiz(topic: str, difficulty: str) -> str:
    """
    Generate a short quiz for the given topic and difficulty level using
    the ChatCompletion API.
    """
    messages = [
        {"role": "system", "content": SYSTEM_PROMPT},
        {
            "role": "user",
            "content": (
                f"Create a short quiz (3-5 questions) about {topic} for a {difficulty} level learner. "
                "Include both the questions and the answers."
            ),
        },
    ]
    return generate_completion(messages)


def prompt_selection(options: Dict[str, str], prompt_text: str) -> str:
    """
    Display a menu based on the provided options dictionary and return the
    user's choice.  Keeps prompting until a valid key is selected.
    """
    while True:
        print(prompt_text)
        for key, label in options.items():
            print(f"{key}. {label}")
        choice = input("Choice: ").strip()
        if choice in options:
            return options[choice]
        else:
            print("Invalid selection. Please try again.\n")


def main() -> None:
    """Main entry point for the application."""
    # Ensure the API key is set before we attempt any calls.
    ensure_api_key()

    print("Welcome to the DSA Learning App!\n")

    # Select topic
    topic = prompt_selection(TOPICS, "Please select a topic to study:")

    # Select difficulty
    difficulty = prompt_selection(DIFFICULTIES, "\nSelect a difficulty level:")

    print("\nGenerating your lesson... (this may take a few seconds)\n")
    lesson = generate_lesson(topic, difficulty)
    print("\n--- Lesson Start ---\n")
    print(lesson)
    print("\n--- Lesson End ---\n")

    # Optionally, ask for a quiz
    while True:
        quiz_input = input("Would you like a quiz on this topic? (y/n): ").strip().lower()
        if quiz_input in {"y", "yes"}:
            print("\nGenerating quiz...\n")
            quiz = generate_quiz(topic, difficulty)
            print("\n--- Quiz Start ---\n")
            print(quiz)
            print("\n--- Quiz End ---\n")
            break
        elif quiz_input in {"n", "no"}:
            print("\nNo quiz selected. Happy learning!\n")
            break
        else:
            print("Please answer with 'y' or 'n'.")


if __name__ == "__main__":
    main()